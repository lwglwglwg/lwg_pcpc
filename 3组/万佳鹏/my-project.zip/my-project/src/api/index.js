const api = {
  login:'login',
  rights:'menus',
  user:'users',
  roles:'roles',
  quanlist:'rights',
  goods:'goods',
  categories:'categories',
  orders:'orders',
  kuaidi:'kuaidi'
}

export default api
